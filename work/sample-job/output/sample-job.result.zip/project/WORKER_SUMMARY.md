# Worker Summary

- job_id: sample-job
- status: failed
- stop_reason: assistant_exit_1
- iterations_attempted: 1
